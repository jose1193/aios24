<a href="/">
    <img src="{{ asset('img/logo2.png') }}" style="height: 100px" alt="logo">

</a>
