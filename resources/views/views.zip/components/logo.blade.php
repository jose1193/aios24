 <img src="{{ asset('img/logo.jpg') }}" class=" mx-auto mb-3" style="height: 100px" alt="logo">
