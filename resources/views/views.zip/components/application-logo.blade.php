 <img src="{{ asset('img/logo.jpg') }}" class="h-16 -ml-3" alt="logo">
